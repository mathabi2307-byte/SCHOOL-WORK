import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Functions 
{
    public static void writetofile(String filename, String text)
    {
        try (BufferedWriter BW = new BufferedWriter(new FileWriter(filename,true)))
        {
            BW.write(text);
            BW.newLine();
            BW.close();
        }

        catch (IOException ioe) 
        {
            ioe.printStackTrace();
        }
    }

    public static void readFromFile(String filename)
    {
        try (BufferedReader BR =  new BufferedReader(new FileReader(filename)))
        {
            String text;
            while (( text = BR.readLine()) != null)
            {
                System.out.println(text); 
            }
            

        }
        catch (IOException ioe)

        {
            ioe.printStackTrace();
        }
    }

}
