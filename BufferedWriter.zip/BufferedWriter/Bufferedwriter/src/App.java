public class App 
{
    public static void main(String[] args) throws Exception 
    {
        System.out.println("Hello, World!");
        String filename = ("test.txt");
        String text = ("Ola");


        Functions f = new Functions();
        Functions.writetofile(filename, text);
        f.writetofile(filename, text);
        Functions.readFromFile(filename);
        
    }
}
