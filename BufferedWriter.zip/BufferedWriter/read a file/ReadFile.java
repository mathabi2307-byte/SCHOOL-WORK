
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFile {
    public static void main(String[] args) {

        try {
            // Locate the file
            File file = new File("myfile.txt");

            // Create a Scanner to read the file
            Scanner reader = new Scanner(file);

            // Read and display each line
            while (reader.hasNextLine()) {
                String data = reader.nextLine();
                System.out.println(data);
            }

            // Close the reader
            reader.close();

        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
            e.printStackTrace();
        }
    }
}
