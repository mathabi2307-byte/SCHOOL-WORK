
import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
    public static void main(String[] args) {

        try {
            // Create a file and open it for writing
            FileWriter writer = new FileWriter("myfile.txt");

            // Write text into the file
            writer.write("Hello, welcome to Java!\n");
            writer.write("This is my first file.\n");
            writer.write("I am learning how to write files in Java.");

            // Close the file
            writer.close();

            // Display success message
            System.out.println("File written successfully!");

        } catch (IOException e) {
            System.out.println("An error occurred while writing the file.");
            e.printStackTrace();
        }
    }
}
