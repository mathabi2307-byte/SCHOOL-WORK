import java.util.Scanner;

public class SimpleCalculator {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String calculation;

        System.out.println("Welcome to the simple calculator.");
        System.out.println("Enter addition or subtraction in this format: number operator number");
        System.out.println("Example: 1+1");
        System.out.println("Enter -1 to exit.");

        // Perpetual loop
        while (true) {

            System.out.print("\nEnter calculation: ");
            calculation = input.nextLine();

            // Escape sequence
            if (calculation.equals("-1")) {
                System.out.println("You entered an escape sequence.");
                break;
            }

            // Remove spaces from an input such as: 1 + 1
            calculation = calculation.replace(" ", "");

            if (calculation.indexOf("+") != -1) {

                String[] values = calculation.split("\\+");

                int firstNumber = Integer.parseInt(values[0]);
                int secondNumber = Integer.parseInt(values[1]);

                int answer = firstNumber + secondNumber;

                System.out.println("= " + answer);

            } else if (calculation.indexOf("-") != -1) {

                String[] values = calculation.split("-");

                int firstNumber = Integer.parseInt(values[0]);
                int secondNumber = Integer.parseInt(values[1]);

                int answer = firstNumber - secondNumber;

                System.out.println("= " + answer);

            } else {
                System.out.println("Invalid format. Use an example such as 1+1 or 3-3.");
            }
        }

        input.close();
    }
}