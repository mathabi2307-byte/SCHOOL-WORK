public class SachinTendulkariApplication {

    public static void main(String[] args) {

        // Declare and initialize the String variable
        String myName = "SachinTendulkari";

        // Display Tendulkari
        String surname = myName.substring(6);
        System.out.println(surname);

        // Display Sachin
        String firstName = myName.substring(0, 6);
        System.out.println(firstName);

        // Count the vowels
        int vowelCount = 0;
        String vowels = "aeiou";

        for (int i = 0; i < myName.length(); i++) {
            char letter = Character.toLowerCase(myName.charAt(i));

            if (vowels.indexOf(letter) != -1) {
                vowelCount++;
            }
        }

        // Display number of vowels
        System.out.println("Number of vowels: " + vowelCount);
    }
}