import java.util.Scanner;

public class NumberPressed {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int monthNumber;

        // Prompt the user
        System.out.println("Enter number to represent a month you are interested in:");

        // Check whether the user entered a number
        if (input.hasNextInt()) {
            monthNumber = input.nextInt();
        } else {
            input.next(); // Read the invalid input
            monthNumber = 0;
        }

        // Display the selected month and approximate number of days
        switch (monthNumber) {

            case 1:
                System.out.println("You chose a number that corresponds to January.");
                System.out.println("January has 31 days.");
                break;

            case 2:
                System.out.println("You chose a number that corresponds to February.");
                System.out.println("February usually has 28 days except in a leap year when it has 29.");
                break;

            case 3:
                System.out.println("You chose a number that corresponds to March.");
                System.out.println("March has 31 days.");
                break;

            case 4:
                System.out.println("You chose a number that corresponds to April.");
                System.out.println("April has 30 days.");
                break;

            case 5:
                System.out.println("You chose a number that corresponds to May.");
                System.out.println("May has 31 days.");
                break;

            case 6:
                System.out.println("You chose a number that corresponds to June.");
                System.out.println("June has 30 days.");
                break;

            case 7:
                System.out.println("You chose a number that corresponds to July.");
                System.out.println("July has 31 days.");
                break;

            case 8:
                System.out.println("You chose a number that corresponds to August.");
                System.out.println("August has 31 days.");
                break;

            case 9:
                System.out.println("You chose a number that corresponds to September.");
                System.out.println("September has 30 days.");
                break;

            case 10:
                System.out.println("You chose a number that corresponds to October.");
                System.out.println("October has 31 days.");
                break;

            case 11:
                System.out.println("You chose a number that corresponds to November.");
                System.out.println("November has 30 days.");
                break;

            case 12:
                System.out.println("You chose a number that corresponds to December.");
                System.out.println("December has 31 days.");
                break;

            default:
                System.out.println("No number detected.");
                break;
        }

        input.close();
    }
}