public class LesothoKingdomMountain {
    public static void main(String[] args) {
        // Declare and initialize the string variable
        String fullName = "LesothoMountainKingdom";

        // Use different String methods to manipulate the string
        String kingdom = fullName.substring(15); // Kingdom
        String mountain = fullName.substring(7, 15); // Mountain
        String lesotho = fullName.substring(0, 7); // Lesotho

        // Display the words in separate lines
        System.out.println(kingdom);
        System.out.println(mountain);
        System.out.println(lesotho);

        // Convert the full string to uppercase and display it
        String upperCaseName = fullName.toUpperCase();
        System.out.println(upperCaseName);

        // Count consonants in the string
        int consonantCount = 0;
        

        for (int i = 0; i < fullName.length(); i++) {
             { char letter = Character.toLowerCase(fullName.charAt(i));

            if (letter >= 'a' && letter <= 'z'
                    && letter != 'a'
                    && letter != 'e'
                    && letter != 'i'
                    && letter != 'o'
                    && letter != 'u') {
                         consonantCount++;

                    }
               
            }
        }

        System.out.println("The number of consonants is: " + consonantCount);
    }
}

