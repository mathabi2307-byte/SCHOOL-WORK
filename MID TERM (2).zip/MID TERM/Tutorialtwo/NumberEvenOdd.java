public class NumberEvenOdd 
{
    public static void main(String[] args) 

    {
        // Loop through  numbers 1 to 10
        for (int number = 1; number <= 10; number++)
        {
             // Pass the number by value 
            checkevenodd(number);
        }
    }

    // Method to check whether a number is odd or even
    public static void checkevenodd(int number) 
    {
        // Cast the integer to float
        float value = (float) number;

        // Use remainder and switch statement
        switch (number % 2)
        {
            case 0:
            System.out.println(value + " is even");
            break;

            case 1:
                System.out.println(value + " is odd");
                break;
        }
    }

}
