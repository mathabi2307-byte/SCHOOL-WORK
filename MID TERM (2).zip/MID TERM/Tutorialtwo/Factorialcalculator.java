
import java.util.Scanner;

public class Factorialcalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a non-negative number: ");
        int number = scanner.nextInt();

        if (number < 0) {
            System.out.println("Factorial is not defined for negative numbers.");
        } else {
            long factorial = 1;
            int counter = 1;

            do {
                factorial *= counter;
                counter++;
            } while (counter <= number);

            System.out.println("Factorial of " + number + " is: " + factorial);
        }

        scanner.close();
    }
}