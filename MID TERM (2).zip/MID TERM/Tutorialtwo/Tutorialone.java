import java.util.Scanner;

public class Tutorialone {
    public static void main(String[] args) { 
        
        Scanner input = new Scanner(System.in);

        // Get student details
        System.out.print("Enter student name: ");
        String name = input.nextLine();

        System.out.print("Enter marks for Mathematics: ");
        int mathematics = input.nextInt();

        System.out.print("Enter marks for English: ");
        int english = input.nextInt();

        System.out.print("Enter marks for Computer science: ");
        int computerScience = input.nextInt();

        // Arithmetic operator: +
        int total = mathematics + english + computerScience;

        // Type casting: int to double
        double average = (double) total / 3;

        // Relational operator: >= 
        boolean passed = average >= 50;

        // Logical operator: &&
        boolean excellent = average >= 80 && mathematics >= 80;

        // Assignment operator: +=
        int bonus = 5;
        total += bonus;

        // Display results
        System.out.println("\n----- STUDENT RESULTS -----");
        System.out.println("Student Name: " + name);
        System.out.println("Total Marks: " + total);
        System.out.println("Average: " + average);


        if (excellent) {

            System.out.println("Perfomance: Excellent");
        } else if (passed) {
            System.out.println("Perfomance: Pass");
        } else {
            System.out.println("Perfomance: Fail");
        }
        
        input.close();


    }
}