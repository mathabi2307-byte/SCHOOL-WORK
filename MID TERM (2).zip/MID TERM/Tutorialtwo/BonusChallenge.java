import java.util.Scanner;

public class BonusChallenge {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        for (char choice = ' '; choice != 'F';) {
            System.out.println("\n--- Activities Menu ---");
            System.out.println("A. Multiplication Table");
            System.out.println("B. Sum of Even Numbers");
            System.out.println("C. Factorial Calculator");
            System.out.println("F. Exit");
            System.out.print("Choose an option: ");

            choice = Character.toUpperCase(scanner.next().charAt(0));

            switch (choice) {
                case 'A':
                    System.out.print("Enter a number: ");
                    int number = scanner.nextInt();

                    for (int i = 1; i <= 12; i++) {
                        System.out.println(number + " x " + i + " = " + number * i);
                    }
                    break;

                case 'B':
                    int sum = 0;
                    int evenNumber = 2;

                    while (evenNumber <= 100) {
                        sum += evenNumber;
                        evenNumber += 2;
                    }

                    System.out.println("Sum of even numbers: " + sum);
                    break;

                case 'C':
                    System.out.print("Enter a non-negative number: ");
                    int factorialNumber = scanner.nextInt();
                    long factorial = 1;
                    int counter = 1;

                    if (factorialNumber < 0) {
                        System.out.println("Invalid number.");
                    } else {
                        do {
                            factorial *= counter;
                            counter++;
                        } while (counter <= factorialNumber);

                        System.out.println("Factorial: " + factorial);
                    }
                    break;

                case 'F':
                    System.out.println("Program exited.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }

        scanner.close();
    }
}
