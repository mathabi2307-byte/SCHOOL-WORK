import java.util.Scanner;

public class TutorialTwo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number from 1 to 12: ");
        int number = scanner.nextInt();

        if (number >= 1 && number <= 12) {
            for (int i = 1; i <= 12; i++) {
                System.out.println(number + " x " + i + " = " + (number * i));
            }
        } else {
            System.out.println("Please enter a number from 1 to 12.");
        }

        scanner.close();
    }
}
