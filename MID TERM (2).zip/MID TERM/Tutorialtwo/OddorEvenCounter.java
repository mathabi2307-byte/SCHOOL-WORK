public class OddorEvenCounter {
    public static void main(String[] args) {
        int number = 1;
        int oddCount = 0;
        int evenCount = 0;

        while (number <= 50) {
            if (number % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }

            number++;
        }

        System.out.println("Even numbers: " + evenCount);
        System.out.println("Odd numbers: " + oddCount);
    }
}
