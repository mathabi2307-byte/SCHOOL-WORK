
import java.util.Scanner;

public class AtmSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double balance = 1000.00;
        int choice;

        do {
            System.out.println("\n--- ATM Menu ---");
            System.out.println("1. Check balance");
            System.out.println("2. Deposit money");
            System.out.println("3. Withdraw money");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.printf("Balance: R%.2f%n", balance);
                    break;

                case 2:
                    System.out.print("Enter deposit amount: R");
                    double deposit = scanner.nextDouble();

                    if (deposit > 0) {
                        balance += deposit;
                        System.out.printf("New balance: R%.2f%n", balance);
                    } else {
                        System.out.println("Deposit must be greater than zero.");
                    }
                    break;

                case 3:
                    System.out.print("Enter withdrawal amount: R");
                    double withdrawal = scanner.nextDouble();

                    if (withdrawal <= 0) {
                        System.out.println("Withdrawal must be greater than zero.");
                    } else if (withdrawal > balance) {
                        System.out.println("Insufficient funds.");
                    } else {
                        balance -= withdrawal;
                        System.out.printf("New balance: R%.2f%n", balance);
                    }
                    break;

                case 4:
                    System.out.println("Thank you for using the ATM.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 4);

        scanner.close();
    }
}