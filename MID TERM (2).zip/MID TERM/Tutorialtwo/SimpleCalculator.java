public class SimpleCalculator {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 5;
        int num3 = 2;

        int sum = num1 + num2 + num3;
        int difference = num1 - num2 - num3;
        int product = num1 * num2 * num3;
        double quotient = (double) num1 / num2 / num3;

        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);

    }
}
