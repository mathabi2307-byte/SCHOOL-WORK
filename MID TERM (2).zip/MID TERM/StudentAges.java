public class StudentAges {
    public static void main(String[] args) {

        // Array containing 15 student ages
        int[] ages = {18, 20, 22, 19, 25, 21, 23, 17, 24, 20, 26, 19, 22, 18, 21};

        int youngest = ages[0];
        int oldest = ages[0];
        int total = 0;
        int students21OrOlder = 0;

        // Find youngest, oldest, total, and students aged 21 or older
        for (int age : ages) {
            if (age < youngest) {
                youngest = age;
            }

            if (age > oldest) {
                oldest = age;
            }

            total += age;

            if (age >= 21) {
                students21OrOlder++;
            }
        }

        double average = (double) total / ages.length;

        System.out.println("Youngest age: " + youngest);
        System.out.println("Oldest age: " + oldest);
        System.out.println("Average age: " + average);

        System.out.println("\nAges below the average:");
        for (int age : ages) {
            if (age < average) {
                System.out.println(age);
            }
        }

        System.out.println("\nEven ages:");
        for (int age : ages) {
            if (age % 2 == 0) {
                System.out.println(age);
            }
        }

        System.out.println("\nNumber of students aged 21 or older: "
                + students21OrOlder);
    }
}
