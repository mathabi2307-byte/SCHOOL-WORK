import java.util.Scanner;
import java.time.LocalDate;

public class PrimarySchoolApp {
    public static void main(String[] args) {
        
        // Create Scanner object for user input
        Scanner input = new Scanner(System.in);

        // Prompt user to enter student name
        System.out.println("Please enter the name of the student:");
        String studentName  = input.nextLine();

        // Prompt user to enter year of birth
        System.out.println("Please enter Year of Birth:");
        int yearofBirth = input.nextInt();

        // Prompt user to enter Marks
        System.out.println("Please enter the mark for Math:");
        float mathMark = input.nextFloat();

        System.out.println("Please enter mark for Biology:");
        float biologyMark = input.nextFloat();

        System.out.println("Please enter mark for English:");
        float englishMark = input.nextFloat();

        // Calculate student's age using the current year
        int currentYear = LocalDate.now().getYear();
        int age = currentYear - yearofBirth;

        // Calculate average mark
        float average = (mathMark + biologyMark + englishMark) / 3;

        // Adjust average according to age
        if (age < 18) {
            average = average + 5;
        
        }
        else if (age > 19) {
            average = average - 5;
        }
        else {
            average = average * 100;
        }

        // Change only the first letter to uppercase
        String formattedName = studentName.substring(0,1).toUpperCase()
        + studentName.substring(1);

        // Display final output
        System.out.println(formattedName + " is " + age + " years old, and the average is " + average);
        
        input.close();

    }
}
