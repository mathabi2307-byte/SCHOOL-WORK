public class KingLetsieApplication {

    public static void main(String[] args) {

        // Declare and initialize the String variable
        String myName = "KingLetsie";

        // Display King
        String firstName = myName.substring(0, 4);
        System.out.println("First part: " + firstName);

        // Display Letsie
        String secondName = myName.substring(4);
        System.out.println("Second part: " + secondName);

        // Count vowels
        int vowelCount = 0;
        String vowels = "aeiou";

        for (int i = 0; i < myName.length(); i++) {
            char letter = Character.toLowerCase(myName.charAt(i));

            // indexOf returns -1 when the letter is not a vowel
            if (vowels.indexOf(letter) != -1) {
                vowelCount++;
            }
        }

        System.out.println("Number of vowels: " + vowelCount);
    }
}