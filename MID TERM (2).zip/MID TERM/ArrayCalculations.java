public class ArrayCalculations {

    public static void main(String[] args) {

        // Array containing 20 prices
        double[] prices = {
            2.34, 7.89, 1.34, 5.50, 3.25,
            8.75, 4.20, 6.30, 2.99, 9.10,
            1.50, 5.75, 3.80, 7.25, 4.99,
            6.85, 2.50, 8.20, 3.45, 5.10
        };

        double num = 0;

        // Calculate the sum
        for (int i = 0; i < prices.length; i++) {
            num = num + prices[i];
        }

        System.out.println("The sum of all prices is: M" + num);

        // Display prices less than M5.00
        System.out.println("\nPrices less than M5.00:");

        for (int i = 0; i < prices.length; i++) {
            if (prices[i] < 5.00) {
                System.out.println("M" + prices[i]);
            }
        }

        // Calculate the average
        double average = num / prices.length;

        System.out.println("\nThe average price is: M" + average);

        // Display prices higher than the average
        System.out.println("\nPrices higher than the average:");

        for (int i = 0; i < prices.length; i++) {
            if (prices[i] > average) {
                System.out.println("M" + prices[i]);
            }
        }
    }
}
