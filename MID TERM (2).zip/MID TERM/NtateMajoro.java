public class NtateMajoro {
    public static void main(String[] args) {
        // Declare and initialize the string variable
        String myName = "NtateMajoro";

        // Use substring() to split the string into two parts
        String secondPart = myName.substring(5); // Majoro
        String firstPart = myName.substring(0, 5); // Ntate

        // Display the required output
        System.out.println(secondPart);
        System.out.println();
        System.out.println(firstPart);
        System.out.println();

        // Count vowels using a loop and a String method
        int num = 0;
        String vowels = "aeiou";

        for (int i = 0; i < myName.length(); i++) {
            char ch = Character.toLowerCase(myName.charAt(i));
            if (vowels.indexOf(ch) != -1) {
                num++;
            }
        }

        System.out.println("The number of vowels is: " + num);
    }
}

